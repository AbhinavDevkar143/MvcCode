/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.utility;

/**
 *
 * @author PROCORNER EDUFLEX 60
 */
import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

public class DbUtil {

    private final String dburl = "jdbc:mysql://localhost:3306/ajaxdb";
    private final String name = "root";
    private final String pass = "";
    private DataSource ds = null;
    private Connection conn;

    public Connection getFinConn(final String aliasName) {
        try {
            Driver driver = new com.mysql.jdbc.Driver();
            ds = new SimpleDriverDataSource(driver, dburl, name, pass);
            conn = ds.getConnection();
        } catch (SQLException e1) {
            return conn;
        }
        return conn;
    }

    public void releaseFinConn(Connection con) {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DbUtil.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
