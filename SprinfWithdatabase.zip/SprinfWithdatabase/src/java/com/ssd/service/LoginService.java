/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ssd.service;

import com.ssd.bean.LoginBean;
import com.utility.SQLUtility;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;

/**
 *
 * @author Abhinav
 */
public class LoginService {

    public String chekLogin(LoginBean loginBean) throws ClassNotFoundException, SQLException {

        if (loginBean.getUserName().equals("admin") && loginBean.getUserPassword().equals("admin123")) {

            return "checkLogin";
        } else {

            return "error";
        }
        
     }

}
