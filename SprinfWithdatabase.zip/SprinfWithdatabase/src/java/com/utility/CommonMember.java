package com.utility;
//.utility;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author root
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CommonMember {
    //No of records to be displayed

    public static final int recordsPerPage = 5;
    public static final String strErrorLogPath = "D:\\logs\\";

    public static void appendLogFile(String data){
        Date curDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
        String currDateStr = sdf.format(curDate);
        String currDateStr1 = sdf1.format(curDate);
        data = currDateStr1 + " => " + data;
        String strFileName, strData;
        if (strErrorLogPath != null) {
            try {
                strFileName = strErrorLogPath + "logindata" + currDateStr + ".txt";
                strData = data;
                File f = new File(strFileName);
                FileWriter fw = null;
                try {
                    fw = new FileWriter(f, true);
                } catch (IOException ex) {
                    Logger.getLogger(CommonMember.class.getName()).log(Level.SEVERE, null, ex);
                }
                PrintWriter pw = new PrintWriter(fw);
                pw.println("---------- Date : " + Calendar.getInstance().getTime());
                pw.println(strData);
                pw.close();
                fw.close();
            } catch (IOException ex) {
                Logger.getLogger(CommonMember.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
