package property;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 *
 * @author PROCORNER EDUFLEX 60
 */
public class common
{
    public static String getValue(String paramString) 
    {
        InputStream localInputStream = null;
        String returnString="0";
        try 
        {
            Properties appEnvProperties = new Properties();
            localInputStream = Class.forName("property.common").getResourceAsStream("/property/common.properties");
            appEnvProperties.load(localInputStream);
            returnString = appEnvProperties.getProperty(paramString);
        } 
        catch (ClassNotFoundException ex) 
        {
             //CommonMember.appendTraceLogFile(" Error : " + CommonFunctions.getErrorStack(ex));
        } 
        catch (IOException ex) 
        {
            //CommonMember.appendTraceLogFile(" Error : " + CommonFunctions.getErrorStack(ex));
        } 
        finally {
            try 
            {
                if(localInputStream != null)
                {    
                    localInputStream.close();
                }    
            } catch 
                    (IOException ex) 
            {
                //CommonMember.appendTraceLogFile(" Error : " + CommonFunctions.getErrorStack(ex));
            }

        }
        return returnString;
    } 
}
