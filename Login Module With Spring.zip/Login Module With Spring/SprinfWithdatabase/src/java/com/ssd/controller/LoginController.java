/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ssd.controller;

import com.ssd.bean.LoginBean;
import com.ssd.service.LoginService;
import com.utility.CommonMember;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Abhinav
 */
public class LoginController  extends MultiActionController
{
    
    LoginService loginService=new LoginService();
    public ModelAndView showLogin(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("login");
        return mv;
    }
    public ModelAndView checkLogin(HttpServletRequest request,HttpServletResponse response , LoginBean loginBean) throws ClassNotFoundException, SQLException{
       
       String page="";
       int logcheck;
       
       logcheck=loginService.chekLogin(loginBean);
       if(logcheck>0){
           page="checkLogin";
       }else{
           page="error";
       }
       ModelAndView mv = new ModelAndView(page);
       // mv.addObject("name", loginBean.getUserName());
       
        // CommonMember.appendLogFile("categoryList=="+loginBean.getUserName());
        
       return mv;
    }
}
