/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ssd.service;

import com.ssd.bean.LoginBean;
import com.ssd.datamanager.LoginManager;
import com.utility.SQLUtility;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;

/**
 *
 * @author Abhinav
 */
public class LoginService {

    LoginManager loginManager=new LoginManager();
   public int chekLogin(LoginBean loginBean) throws ClassNotFoundException, SQLException{
       return loginManager.chekLogin(loginBean);
   }

}
