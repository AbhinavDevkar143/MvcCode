/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.utility;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mockrunner.mock.jdbc.MockResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;
import org.springframework.jdbc.support.rowset.SqlRowSet;

/**
 *
 * @author njuser
 */
public class SQLUtility
{

    //private static long totalCalls = 0;
    private static DbUtil dbConnPoolManager = new DbUtil();


    public int persist(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            return jdbcTemplate.update(sqlQuery);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to fire insert, update and
     * delete statements. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return int : either (1) the row count for SQL Data Manipulation Language
     * (DML) statements or (2) 0 for SQL statements that return nothing
     * @throws SQLException
     */
    public int persist(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            return npJdbcTemplate.update(sqlQuery, paramSource);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to fire insert statements
     * from which Key can be returned. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param generatedKeys : Auto Generated Keys
     * @param paramSource : Bind variables for query.
     * @return int : either (1) the row count for SQL Data Manipulation Language
     * (DML) statements or (2) 0 for SQL statements that return nothing
     * @throws SQLException
     */
    public int persist(final String aliasName, final String sqlQuery, KeyHolder generatedKeys, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            return npJdbcTemplate.update(sqlQuery, paramSource, generatedKeys);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to fire insert, update and
     * delete statements. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : Array of SQL query to fire.
     * @return int : either (1) Array of the row count for SQL Data Manipulation
     * Language (DML) statements or (2) Array of 0 for SQL statements that
     * return nothing
     * @throws SQLException
     */
    public int[] persistBatch(final String aliasName, final String sqlQuery[]) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            return jdbcTemplate.batchUpdate(sqlQuery);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type int. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @return int : Integer result of given query.
     * @throws SQLException
     */
    public int getInt(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            return jdbcTemplate.queryForInt(sqlQuery);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type int. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return int : Integer result of given query.
     * @throws SQLException
     */
    public int getInt(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            return npJdbcTemplate.queryForInt(sqlQuery, paramSource);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type long. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @return long : Long result of given query.
     * @throws SQLException
     */
    public long getLong(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            return jdbcTemplate.queryForLong(sqlQuery);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type long. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return long : Long result of given query.
     * @throws SQLException
     */
    public long getLong(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            return npJdbcTemplate.queryForLong(sqlQuery, paramSource);
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type String. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @return String : String result of given query.
     * @throws SQLException
     */
    public String getString(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            return (String) jdbcTemplate.queryForObject(sqlQuery, String.class);
        }
        catch (EmptyResultDataAccessException e)
        {
            return null;
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return single value of
     * type String. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return String : String result of given query.
     * @throws SQLException
     */
    public String getString(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            return (String) npJdbcTemplate.queryForObject(sqlQuery, paramSource, String.class);
        }
        catch (EmptyResultDataAccessException e)
        {
            return null;
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return List. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @return List : List result of given query.
     * @throws SQLException
     */
    public List getList(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            List l = jdbcTemplate.queryForList(sqlQuery);
//            String server_type = FinPack.getProperty("server_type");
//            if (server_type.equals("prod")
//                    || server_type.equals("test"))
//            {
//                List lOut = new ArrayList();
//                int cnt = l.size();
//                for (int i = 0; i < cnt; i++)
//                {
//                    Map m1 = (Map) l.get(i);
//                    LinkedHashMap m2 = new LinkedHashMap();
//                    m2.putAll(m1);
//                    lOut.add(m2);
//                }
//                return lOut;
//            }
            return l;
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return List. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return List : List result of given query.
     * @throws SQLException
     */
    public List getList(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            List l = npJdbcTemplate.queryForList(sqlQuery, paramSource);
//            String server_type = FinPack.getProperty("server_type");
//            if (server_type.equals("prod")
//                    || server_type.equals("test"))
//            {
//                List lOut = new ArrayList();
//                int cnt = l.size();
//                for (int i = 0; i < cnt; i++)
//                {
//                    Map m1 = (Map) l.get(i);
//                    LinkedHashMap m2 = new LinkedHashMap();
//                    m2.putAll(m1);
//                    lOut.add(m2);
//                }
//                return lOut;
//            }
            return l;
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }
    }
//
//    /**
//     * *
//     * Develop By Bhatu Mali : This function is used to return SqlRowSet. <br>
//     *
//     * @param aliasName : Alias name to connect with database.
//     * @param sqlQuery : SQL query to fire.
//     * @return SqlRowSet : SqlRowSet of given query.
//     * @throws SQLException
//     */
//    public SqlRowSet getRowSet(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
//    {
//        System.out.println("Here");
//        
//        Connection conn = null;
//        try
//        {
//            conn = dbConnPoolManager.getFinConn(aliasName);
//            DataSource ds = new SingleConnectionDataSource(conn, true);
//            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
//            SqlRowSet srs = jdbcTemplate.queryForRowSet(sqlQuery);
//            return srs;
//        }
//        finally
//        {
//            dbConnPoolManager.releaseFinConn(conn);
//        }
//    }
//
//    /**
//     * *
//     * Develop By Bhatu Mali : This function is used to return SqlRowSet. <br>
//     *
//     * @param aliasName : Alias name to connect with database.
//     * @param sqlQuery : SQL query to fire.
//     * @param paramSource : Bind variables for query.
//     * @return SqlRowSet : SqlRowSet of given query.
//     * @throws SQLException
//     */
//    public SqlRowSet getRowSet(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
//    {
//        
//        Connection conn = null;
//        try
//        {
//            conn = dbConnPoolManager.getFinConn(aliasName);
//            DataSource ds = new SingleConnectionDataSource(conn, true);
//            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
//            SqlRowSet srs = npJdbcTemplate.queryForRowSet(sqlQuery, paramSource);
//
//            int totalRecords = 0;
//            while (srs.next())
//            {
//                totalRecords++;
//            }
//            srs.beforeFirst();
//            return srs;
//        }
//        finally
//        {
//            dbConnPoolManager.releaseFinConn(conn);
//        }
//    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return SqlRowSet. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @return SqlRowSet : SqlRowSet of given query.
     * @throws SQLException
     */
    public SqlRowSet getRowSet(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
    {
        

        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
            SqlRowSet srs = jdbcTemplate.queryForRowSet(sqlQuery);
            return srs;
        }
        catch (BadSqlGrammarException ex)
        {
            // code to solve integrationsolution problem

            if (ex.getMessage().contains("Table") && ex.getMessage().contains("doesn't exist"))
            {
                List l = getList(aliasName, sqlQuery);
                MockResultSet mockResultSet = new MockResultSet("myResultSet");
                Map map = null;

                int size = l.size();
                for (int i = 0; i < size; i++)
                {
                    map = (Map) l.get(i);
                    Object[] cells = map.values().toArray();
                    mockResultSet.addRow(cells);
                }

                Object[] cols = map.keySet().toArray();
                for (int i = 0; i < cols.length; i++)
                {
                    mockResultSet.addColumn((String) cols[i]);
                }
                SqlRowSet srs = new ResultSetWrappingSqlRowSet(mockResultSet);
                return srs;
            }
            else
            {
                throw new SQLException(ex);
            }

//            if (ex.getMessage().contains("Table") && ex.getMessage().contains("doesn't exist"))
//            {
//                Statement stmt = null;
//                ResultSet rs = null;
//                try
//                {
//                    stmt = conn.createStatement();
//                    rs = stmt.executeQuery(sqlQuery);
//                    SqlRowSet srs = new ResultSetWrappingSqlRowSet(rs);
//                    srs.beforeFirst();
//                    return srs;
//                }
//                finally
//                {
//                    if (rs != null)
//                    {
//                        rs.close();
//                        rs = null;
//                    }
//                    if (stmt != null)
//                    {
//                        stmt.close();
//                        stmt = null;
//                    }
//                }
//            }
//            else
//            {
//                throw new SQLException(ex);
//            }
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }


    }
//
//    /**
//     * *
//     * Develop By Bhatu Mali : This function is used to return SqlRowSet. <br>
//     *
//     * @param aliasName : Alias name to connect with database.
//     * @param sqlQuery : SQL query to fire.
//     * @param paramSource : Bind variables for query.
//     * @return SqlRowSet : SqlRowSet of given query.
//     * @throws SQLException
//     */
//    public SqlRowSet getRowSet(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
//    {
//        
//        Connection conn = null;
//        try
//        {
//            conn = dbConnPoolManager.getFinConn(aliasName);
//            DataSource ds = new SingleConnectionDataSource(conn, true);
//            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
//            SqlRowSet srs = npJdbcTemplate.queryForRowSet(sqlQuery, paramSource);
//            return srs;
//        }
//        finally
//        {
//            dbConnPoolManager.releaseFinConn(conn);
//        }
//    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to return SqlRowSet. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param sqlQuery : SQL query to fire.
     * @param paramSource : Bind variables for query.
     * @return SqlRowSet : SqlRowSet of given query.
     * @throws SQLException
     */
    public SqlRowSet getRowSet(final String aliasName, final String sqlQuery, final SqlParameterSource paramSource) throws ClassNotFoundException, SQLException
    {
        
        Connection conn = null;
        try
        {
            conn = dbConnPoolManager.getFinConn(aliasName);
            DataSource ds = new SingleConnectionDataSource(conn, true);
            NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(ds);
            SqlRowSet srs = npJdbcTemplate.queryForRowSet(sqlQuery, paramSource);
            return srs;
        }
        catch (BadSqlGrammarException ex)
        {
            // code to solve integrationsolution problem

            if (ex.getMessage().contains("Table") && ex.getMessage().contains("doesn't exist"))
            {
                List l = getList(aliasName, sqlQuery, paramSource);
                MockResultSet mockResultSet = new MockResultSet("myResultSet");
                Map map = null;

                int size = l.size();
                for (int i = 0; i < size; i++)
                {
                    map = (Map) l.get(i);
                    Object[] cells = map.values().toArray();
                    mockResultSet.addRow(cells);
                }

                Object[] cols = map.keySet().toArray();
                for (int i = 0; i < cols.length; i++)
                {
                    mockResultSet.addColumn((String) cols[i]);
                }
                SqlRowSet srs = new ResultSetWrappingSqlRowSet(mockResultSet);
                return srs;
            }
            else
            {
                throw new SQLException(ex);
            }
        }
        finally
        {
            dbConnPoolManager.releaseFinConn(conn);
        }


    }

    /**
     * *
     * This function is used to get ResultSet using SQL and Alias Connection and
     * statement will auto close in ResultSet.close(). <br>
     *
     * @param aliasName : Connection alias.
     * @param sqlQuery : SQL Query.
     * @return ResultSet : java.sql.ResultSet.
     */
//    public ResultSet getResultSet(final String aliasName, final String sqlQuery) throws ClassNotFoundException, SQLException
//    {
//         connCloseFlag = true;
//        DBConnManager dbConnManager = new DBConnManager();
//        conn = dbConnManager.getFinConn(aliasName);
//        st = conn.createStatement();
//        rs = st.executeQuery(sqlQuery);
//        return new ResultSetImpl(aliasName, sqlQuery);
//    }

    // code to create resultset from SQLROWSET
    /**
     * *
     * Develop By Bhatu Mali : This function is used to get ResultSet from
     * SqlRowSet (Disconnected). <br>
     *
     * @param srs : SqlRowSet to be convert in ResultSet.
     * @return ResultSet : Converted ResultSet.
     */
//    public ResultSet getResultSetFromSqlRowSet(final SqlRowSet srs)
//    {
//        return new ResultSetImpl(srs);
//    }
    // Code for calling procedure
    /**
     * *
     * Develop By Bhatu Mali : This function is used to call Oracle store
     * Procedure. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param procName : Procedure name to call.
     * @param paramValues : Parameter values to pass.
     * @param params : Parameters information object.
     * @return Map : out parameters, if any. <br><br> <b>Example:</b><br>
     * <u>Imports</u> <br><br>import java.sql.Types; <br>import java.util.Map;
     * <br>import java.util.Map; <br>import
     * com.finlogic.util.persistence.ProcedureParam; <br>import
     * com.finlogic.util.persistence.SQLUtility; <br><br><u>Code</u> <br><br>Map
     * paramValues=new HashMap(); <br>paramValues.put("P1", "Test Value"); <br>
     * <br>ProcedureParam params[]=new ProcedureParam[1]; <br>params[0]=new
     * ProcedureParam(); <br>params[0].setParamDataType(Types.VARCHAR);
     * <br>params[0].setParamInOutType("IN"); <br>params[0].setParamName("P1");
     * <br> <br>SQLUtility sqlUtility = new SQLUtility(); <br>Map results =
     * sqlUtility.callProcedure("mftran","TEST2",paramValues,params);
     * @throws SQLException
     *
     */
//    public Map callProc(final String aliasName, final String procName, final Map paramValues, final ProcedureParam[] params) throws ClassNotFoundException, SQLException
//    {
//        
//        CallStoredProcedure sproc = new CallStoredProcedure();
//        Connection conn = null;
//        try
//        {
//            conn = dbConnPoolManager.getFinConn(aliasName);
//            DataSource ds = new SingleConnectionDataSource(conn, true);
//            return sproc.execute(ds, procName, paramValues, params);
//        }
//        finally
//        {
//            dbConnPoolManager.releaseFinConn(conn);
//        }
//    }

    /**
     * *
     * Develop By Bhatu Mali : This function is used to call Oracle store
     * Procedure. <br>
     *
     * @param aliasName : Alias name to connect with database.
     * @param procName : Procedure name to call.
     * @param paramValues : Parameter values to pass.
     * @param params : Parameters information object.
     * @return Map : out parameters, if any. <br><br> <b>Example:</b><br>
     * <u>Imports</u> <br><br>import java.sql.Types; <br>import java.util.Map;
     * <br>import java.util.Map; <br>import
     * com.finlogic.util.persistence.ProcedureParam; <br>import
     * com.finlogic.util.persistence.SQLUtility; <br><br><u>Code</u> <br><br>Map
     * paramValues=new HashMap(); <br>paramValues.put("P1", "Test Value"); <br>
     * <br>ProcedureParam params[]=new ProcedureParam[1]; <br>params[0]=new
     * ProcedureParam(); <br>params[0].setParamDataType(Types.VARCHAR);
     * <br>params[0].setParamInOutType("IN"); <br>params[0].setParamName("P1");
     * <br> <br>SQLUtility sqlUtility = new SQLUtility(); <br>Map results =
     * sqlUtility.callProcedure("mftran","TEST2",paramValues,params);
     * @throws SQLException
     *
     */
//    public Map callProcedure(final String aliasName, final String procName, final HashMap paramValues, final ProcedureParam[] params) throws ClassNotFoundException, SQLException
//    {
//        
//        CallStoredProcedure sproc = new CallStoredProcedure();
//        Connection conn = null;
//        try
//        {
//            conn = dbConnPoolManager.getFinConn(aliasName);
//            DataSource ds = new SingleConnectionDataSource(conn, true);
//            return sproc.execute(ds, procName, paramValues, params);
//        }
//        finally
//        {
//            dbConnPoolManager.releaseFinConn(conn);
//        }
//    }

    /**
     * Procedure calling class
     */
    //private class CallStoredProcedure extends StoredProcedure
   // {

        /**
         *
         * @param ds Connection
         * @param procSQL Procedure SQL
         * @param paramValues Values to pass
         * @param params Parameters Info
         * @return Map
         */
//        public Map execute(DataSource ds, String procSQL, Map paramValues, ProcedureParam[] params)
//        {
//
//            setDataSource(ds);
//            setSql(procSQL);
//
//            if (params != null)
//            {
//                for (int i = 0; i < params.length; i++)
//                {
//                    if (params[i].getParamInOutType().equalsIgnoreCase("IN"))
//                    {
//                        declareParameter(new SqlParameter(params[i].getParamName(), params[i].getParamDataType()));
//                    }
//                    else if (params[i].getParamInOutType().equalsIgnoreCase("OUT"))
//                    {
//                        declareParameter(new SqlOutParameter(params[i].getParamName(), params[i].getParamDataType()));
//                    }
//                    else if (params[i].getParamInOutType().equalsIgnoreCase("INOUT"))
//                    {
//                        declareParameter(new SqlInOutParameter(params[i].getParamName(), params[i].getParamDataType()));
//                    }
//                }
//            }
//            compile();
//
//            return execute(paramValues);
//        }
   // }
}
