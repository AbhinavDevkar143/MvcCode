/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ssd.datamanager;

import com.ssd.bean.LoginBean;
import com.utility.SQLUtility;
import java.sql.SQLException;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;

/**
 *
 * @author Abhinav
 */
public class LoginManager {
    
    private final StringBuilder sql = new StringBuilder();
    private final SQLUtility sQLUtility = new SQLUtility();
     public String chekLogin(LoginBean loginBean) throws ClassNotFoundException, SQLException {

       sql.setLength(0);
       sql.append("SELECT userName from login where userName=(:userName) and userPassword=(:userPassword)");
       return sQLUtility.getString("", sql.toString(), new BeanPropertySqlParameterSource(loginBean));
        
        
        
     }
}
