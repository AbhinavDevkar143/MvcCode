/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filedemo.apps.datamanager;

import com.filedemo.apps.formbean.Student;
import com.utility.SQLUtility;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

/**
 *
 * @author Abhinav
 */
public class StudentDao {
    
    private final StringBuilder sql = new StringBuilder();
    private final SQLUtility sQLUtility = new SQLUtility();
    public int insertData(Student studentBean) throws ClassNotFoundException, SQLException{
        
        sql.setLength(0);
        sql.append("insert into student(studentName,studentProfile,studentSign) values(:studentName,:studentProfile,:studentSign)");
        return sQLUtility.persist("",sql.toString(),new BeanPropertySqlParameterSource(studentBean));
    }
    public int deleteData(String id) throws ClassNotFoundException, SQLException{
        Map map = new HashMap();
        map.put("studentNo", id);
        sql.setLength(0);
        sql.append("delete from student where studentNo=:studentNo");
        return sQLUtility.persist("", sql.toString(), new MapSqlParameterSource(map));
    }
    public List getList() throws ClassNotFoundException, SQLException{
        
        sql.setLength(0);
        sql.append("select * from student");
        return sQLUtility.getList("", sql.toString());
        
    }
    public List getByStudentNo(String id) throws ClassNotFoundException, SQLException{
        Map map = new HashMap();
        map.put("studentNo", id);
        sql.setLength(0);
        sql.append("select * from student where studentNo=:studentNo");
        return sQLUtility.getList("", sql.toString(), new MapSqlParameterSource(map));
    }
    
    public int updateData(Student studentBean) throws ClassNotFoundException, SQLException{
        
        sql.setLength(0);
        sql.append("update student set studentName=:studentName");
        String profile=studentBean.getStudentProfile();
        String sign=studentBean.getStudentSign();
        if(profile != null && sign != null ){
            sql.append(",studentProfile=:studentProfile,studentSign=:studentSign ");
        }
        else if(profile != null){
            sql.append(",studentProfile=:studentProfile");
        }else if(sign != null){
            sql.append(",studentSign=:studentSign");
        }
        sql.append("  where studentNo=:studentNo");
        return sQLUtility.persist("",sql.toString(),new BeanPropertySqlParameterSource(studentBean));
        
    }
    
}
