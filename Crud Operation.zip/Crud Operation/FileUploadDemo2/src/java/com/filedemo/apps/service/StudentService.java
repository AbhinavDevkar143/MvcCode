/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filedemo.apps.service;

import com.filedemo.apps.datamanager.StudentDao;
import com.filedemo.apps.formbean.Student;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Abhinav
 */
public class StudentService {
    
    StudentDao studentDao=new StudentDao();
    
    public int insertData(Student studentBean) throws ClassNotFoundException, SQLException{
        return studentDao.insertData(studentBean);
    }
     public int deleteData(String id) throws ClassNotFoundException, SQLException{
        
         return studentDao.deleteData(id);
     }
    public List getList() throws ClassNotFoundException, SQLException{
        return studentDao.getList();
    }
     public List getByStudentNo(String id) throws ClassNotFoundException, SQLException{
         return studentDao.getByStudentNo(id);
     }
     public int updateData(Student studentBean) throws SQLException, ClassNotFoundException{
         return studentDao.updateData(studentBean);
     }
    
}
