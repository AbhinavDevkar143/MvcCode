/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filedemo.apps.formbean;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author MyPc
 */
public class Student {
    
    private String studentName;
    private String studentProfile,studentSign;
    private int studentNo;

    public int getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(int studentNo) {
        this.studentNo = studentNo;
    }

    public String getStudentProfile() {
        return studentProfile;
    }

    public void setStudentProfile(String studentProfile) {
        this.studentProfile = studentProfile;
    }

    public String getStudentSign() {
        return studentSign;
    }

    public void setStudentSign(String studentSign) {
        this.studentSign = studentSign;
    }
    
    
    private MultipartFile profile;
    
    private MultipartFile sign;

    public MultipartFile getSign() {
        return sign;
    }

    public void setSign(MultipartFile sign) {
        this.sign = sign;
    }
    

   
    public MultipartFile getProfile() {
        return profile;
    }

    public void setProfile(MultipartFile profile) {
        this.profile = profile;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

   
    
}
