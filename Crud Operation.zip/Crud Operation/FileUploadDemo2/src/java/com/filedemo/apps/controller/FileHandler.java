/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.filedemo.apps.controller;

import com.filedemo.apps.formbean.Student;
import com.filedemo.apps.service.StudentService;
import java.io.File;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author MyPc
 */
public class FileHandler extends MultiActionController {

    StudentService studentService = new StudentService();

    public ModelAndView getForm(HttpServletRequest request, HttpServletResponse response) {

        ModelAndView mv = new ModelAndView("studentform");
        return mv;
    }

    public ModelAndView editForm(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
        ModelAndView mv = new ModelAndView("editstudentform");
        String id = request.getParameter("id");
        String rpath = request.getContextPath();
        mv.addObject("lists", studentService.getByStudentNo(id));
        mv.addObject("projectfoldername", rpath);
        return mv;
    }

    public ModelAndView uploadFile(HttpServletRequest request, HttpServletResponse response, Student formbean) {
        ModelAndView mv = new ModelAndView();
        try {
            //"upload" is Folder name Where we upload our file
            //You Can Put Your Upload Path //Here it is upload in build/web/upload/
            // if you have to remove build folder that's why you have to replace it with blank "" value.
            //after that just joint this path with required folder
            String uploadPathProfile = getServletContext().getRealPath("/").replace("\\build", "").concat("upload\\");
            String uploadPathSign = getServletContext().getRealPath("/").replace("\\build", "").concat("sign\\");

            //Get Uploaded File name && You can insert this name to database
            //uploadFile is a method that return a file name
            String profileName = uploadFile(formbean.getProfile(), uploadPathProfile);
            String signName = uploadFile(formbean.getSign(), uploadPathSign);
            String studentName = formbean.getStudentName();
            // below to value are not in form but inside bean so you have to set name of both image in setter method
            //because inside database only image name will be store. so you have to set it.
            formbean.setStudentProfile(profileName);
            formbean.setStudentSign(signName);
            // this return a project folder name like here FileUploadDemo2
            // now you can bind with any folder of project.
            //it help to create relative path  just because project can run another pc also
            String rpath = request.getContextPath();

            mv.setViewName("studentList");
            studentService.insertData(formbean);
            mv.addObject("lists", studentService.getList());
            // this send relative path start : means project folder name then you have to bind with 
            //another folder like : upload,sign after just add image name that will be receive from database
            // and your image will be display 
            mv.addObject("projectfoldername", rpath);

            System.out.println("FILE NAME : " + profileName + "   Student Name : " + studentName + " Student Sign : " + signName);
            System.out.println("Relative Path : " + rpath);
        } catch (Exception e) {
            System.out.println("Ex : " + e.getMessage());
            mv.setViewName("error");
        }

        return mv;
    }

    public ModelAndView showList(HttpServletRequest request, HttpServletResponse response) {

        ModelAndView mav = new ModelAndView();
        try {
            // this is require because it return relative path :
            // means project foledr name like FileUploadDemo2
            String rpath = request.getContextPath();
            //getList() method return records .
            mav.addObject("lists", studentService.getList());
            //this value access on jsp page : studentList
            mav.addObject("projectfoldername", rpath);
            // it will redirecr on studentList page.
            mav.setViewName("studentList");
        } catch (Exception ex) {
            Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
            //if any hing is wrong happen the error will be raise
            mav.setViewName("error");
            mav.addObject("error", ex.toString());
        }

        return mav;
    }

    public ModelAndView delete(HttpServletRequest request, HttpServletResponse response) {

        ModelAndView mav = new ModelAndView();
        String id = request.getParameter("id");
        try {
            studentService.deleteData(id);
            String rpath = request.getContextPath();
            mav.addObject("lists", studentService.getList());
            mav.addObject("projectfoldername", rpath);
            mav.setViewName("studentList");
        } catch (Exception ex) {
            Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
            mav.setViewName("error");
            mav.addObject("error", ex.toString());
        }
        return mav;
    }

    public ModelAndView update(HttpServletRequest request, HttpServletResponse response, Student formbean) {
        ModelAndView mav = new ModelAndView();

        try {
            
            mav.setViewName("studentList");
            String rpath = request.getContextPath();
            // Image Folder path
            String uploadPathProfile = getServletContext().getRealPath("/").replace("\\build", "").concat("upload\\");
            String uploadPathSign = getServletContext().getRealPath("/").replace("\\build", "").concat("sign\\");
            //image names
            String profileName = uploadFile(formbean.getProfile(), uploadPathProfile);
            String signName = uploadFile(formbean.getSign(), uploadPathSign);
            String studentName = formbean.getStudentName();
            //set image names
            formbean.setStudentProfile(profileName);
            formbean.setStudentSign(signName);
            
            
            
            studentService.updateData(formbean);
            mav.addObject("lists", studentService.getList());
            mav.addObject("projectfoldername", rpath);
            
            System.out.println("FILE NAME : " + profileName + "   Student Name : " + studentName + " Student Sign : " + signName);
            System.out.println("Relative Path : " + rpath);
        } catch (Exception ex) {
            Logger.getLogger(FileHandler.class.getName()).log(Level.SEVERE, null, ex);
            mav.setViewName("error");
            mav.addObject("error", ex.toString());
        }

        return mav;
    }

    /*
        File Upload Function  (Common For All Your Files Upload)
        Return File Name After Upload Successfully...!!!
     */
    public String uploadFile(MultipartFile multipartfile, String uploadPath) {

        try {
            System.out.println("PATH : " + uploadPath);
            File file = new File(uploadPath + multipartfile.getOriginalFilename());
            multipartfile.transferTo(file);
            return multipartfile.getOriginalFilename();
        } catch (Exception e) {
            System.out.println("Ex : " + e.getMessage());
            return null;
        }
    }
}
