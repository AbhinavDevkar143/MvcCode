/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import model.StudentModel;
import servicedao.ServiceDao;

/**
 *
 * @author Abhinav
 */
@MultipartConfig(location = "F:\\MultiFieldMvcCrud\\temping",fileSizeThreshold = 10000)
public class StudentAdd extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        ServiceDao serviceDao=new ServiceDao();
        StudentModel studentModel=new StudentModel();
        ServletContext application=getServletConfig().getServletContext();
        Part part=request.getPart("studentProfile");
        String studentName=request.getParameter("studentName");
        String studentProfile=part.getSubmittedFileName();
        
        
         
        //String studentProfile=request.getParameter("studentProfile");
        // Image Store Into Profile Folder
        String uploadPath = application.getRealPath("").replace("\\build", "")+"\\profile\\"+studentProfile;  
            InputStream inputStream= part.getInputStream();
            FileOutputStream fout= new FileOutputStream(uploadPath);                    
            int c;
            while ((c=inputStream.read())!=-1) {                
                fout.write(c);
            }
            
            // Data Fit Into Model
            studentModel.setStudentName(studentName);
            studentModel.setStudentProfile(studentProfile);
            
            //insert=insert(studentModel);
            int insert=serviceDao.insert(studentModel);
            if(insert>0){
                
                response.sendRedirect("Student");
            }else{
                out.print("Not Inserted");
            }
            //out.print("Name is :"+studentModel.getStudentName());
            //out.print("<br><br> Profile is :"+studentModel.getStudentProfile());
             
            fout.close();
            inputStream.close();
            
        
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
