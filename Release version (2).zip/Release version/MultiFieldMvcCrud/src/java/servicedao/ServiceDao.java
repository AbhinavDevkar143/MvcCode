/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicedao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.StudentModel;

/**
 *
 * @author Abhinav
 */
public class ServiceDao {
    
      Connection con=null;
    String url="jdbc:mysql://localhost:3306/multifield";
    String user="root";
    String password="";
    PreparedStatement preparedStatement=null;
    Statement statement=null;
    
    public ServiceDao(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
  
    public int insert(StudentModel studentModel){
        
        String q="insert into student(studentName,studentProfile) values(?,?)";
        try {
            preparedStatement=con.prepareStatement(q);
            preparedStatement.setString(1,studentModel.getStudentName());
            preparedStatement.setString(2,studentModel.getStudentProfile());
            return preparedStatement.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("Error in Insert :"+e.getMessage());
            return 0;
        }
    }
    public int delete(StudentModel studentModel){
        
        try {
            String q="delete from student where studentRollNo=?";
            preparedStatement=con.prepareStatement(q);
            preparedStatement.setInt(1,studentModel.getStudentRollNo());
            return preparedStatement.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error in Delete :"+e.getMessage());
            return 0;
        }
    }
    
    public int update(StudentModel studentModel){
        try {
            
            String q="update student set studentName = ? , studentProfile = ? where studentRollNo=?";
            preparedStatement=con.prepareStatement(q);
            preparedStatement.setString(1,studentModel.getStudentName());
            preparedStatement.setString(2, studentModel.getStudentProfile());
            preparedStatement.setInt(3, studentModel.getStudentRollNo());
            return preparedStatement.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("Error in Update"+e.getMessage());
            return 0;
        }
    }
    public List getList(){
     
        String q="select * from student";
        try {
            statement=con.createStatement();
            List list=new ArrayList();
            ResultSet resultSet=statement.executeQuery(q);
            while(resultSet.next()){
                
                Map map=new HashMap();
                map.put("studentRollNo",resultSet.getInt("studentRollNo"));
                map.put("studentName",resultSet.getString("studentName"));
                map.put("studentProfile", resultSet.getString("studentProfile"));
                list.add(map);
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error in Display :"+e.getMessage());
            return null;
        }
        
    }
    
    
    public List getSingleList(StudentModel studentModel){
     
        
        try {
            String q="select * from student where studentRollNo=?";
            preparedStatement=con.prepareStatement(q);
            preparedStatement.setInt(1,studentModel.getStudentRollNo());
            ResultSet resultSet=preparedStatement.executeQuery();
            List list=new ArrayList();
            while(resultSet.next()){
                
                Map map=new HashMap();
                map.put("studentRollNo",resultSet.getInt("studentRollNo"));
                map.put("studentName",resultSet.getString("studentName"));
                map.put("studentProfile", resultSet.getString("studentProfile"));
                list.add(map);
            }
            return list;
        } catch (Exception e) {
            System.out.println("Error in Display :"+e.getMessage());
            return null;
        }
        
    }
    
    
}
