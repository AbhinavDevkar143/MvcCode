/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.student.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Abhinav
 */
public class StudentController extends MultiActionController{
    
    public ModelAndView addForm(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("StudentAddForm");
        return mv;
    }
    public ModelAndView editForm(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("StudentEditForm");
        return mv;
    }
    
    public ModelAndView insert(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("insert");
        return mv;
    }
    public ModelAndView update(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("update");
        return mv;
    }
    public ModelAndView delete(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("delete");
        return mv;
    }
    
    public ModelAndView showStudent(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("showStudentGrid");
        return mv;
    }
         
    
}
