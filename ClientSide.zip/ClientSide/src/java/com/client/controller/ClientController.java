/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.client.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

/**
 *
 * @author Abhinav
 */
public class ClientController  extends MultiActionController{
    
    public ModelAndView about(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("about");
        return mv;        
       
    }
    public ModelAndView faq(HttpServletRequest request,HttpServletResponse response){
        
        ModelAndView mv=new ModelAndView("faq");
        return mv;        
       
    }
}
